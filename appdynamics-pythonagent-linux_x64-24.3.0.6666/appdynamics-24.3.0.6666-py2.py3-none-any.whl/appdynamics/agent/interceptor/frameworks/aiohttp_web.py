import sys

from appdynamics.agent.core.eum import inject_eum_metadata
from appdynamics.agent.models.transactions import ENTRY_AIOHTTP
from ..base import EntryPointInterceptor
from appdynamics.aiohttp_lib import LazyAioHTTPRequest


class AIOHTTPInterceptor(EntryPointInterceptor):
    def attach(self, application):
        super(AIOHTTPInterceptor, self).attach(application)

    async def __handle(self, _handle, instance, request):
        bt = self.start_transaction(ENTRY_AIOHTTP, LazyAioHTTPRequest(request))
        try:
            response = await _handle(instance, request)
            self.make_response_wrapper(response)
        except:
            with self.log_exceptions():
                if bt:
                    bt.add_exception(*sys.exc_info())
            raise
        finally:
            self.end_transaction(bt)
        return response

    def make_response_wrapper(self, response):
        """Deal with HTTP status codes, errors and EUM correlation.

        """
        with self.log_exceptions():
            bt = self.bt
            if bt:
                # Store the HTTP status code and deal with errors.
                status_code = response.status
                msg = response.reason
                self.handle_http_status_code(bt, int(status_code), msg)

                # Inject EUM metadata into the response headers.
                inject_eum_metadata(self.agent.eum_config, bt, response.headers)

        return response


def intercept_aiohttp_web(agent, mod):
    AIOHTTPInterceptor(agent, mod.Application).attach('_handle')
