from __future__ import unicode_literals
from appdynamics.lang import urlparse
from . import HTTPConnectionInterceptor


class AioHTTPClientInterceptor(HTTPConnectionInterceptor):

    def __request(self, request, client, method, url, *args, **kwargs):

        exit_call = self.start_exit_call(url)
        if exit_call:
            correlation_header = self.make_correlation_header(exit_call)
            if correlation_header:
                headers = kwargs.setdefault('headers', {})
                headers[correlation_header[0]] = correlation_header[1]

        response = request(client, method, url, *args, **kwargs)

        self.end_exit_call(exit_call)

        return response

    def start_exit_call(self, url):
        bt = self.bt
        if not bt:
            return None

        parsed_url = urlparse(url)
        port = parsed_url.port or ('443' if parsed_url.scheme == 'https' else '80')
        backend = self.get_backend(parsed_url.hostname, port, parsed_url.scheme, url)
        if not backend:
            return None

        return super(AioHTTPClientInterceptor, self).start_exit_call(bt, backend, operation=parsed_url.path)

    def end_exit_call(self, exit_call):
        super(AioHTTPClientInterceptor, self).end_exit_call(exit_call)


def intercept_aiohttp_client(agent, mod):
    AioHTTPClientInterceptor(agent, mod.ClientSession).attach('_request')
